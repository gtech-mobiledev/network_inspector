class Endpoint {
  static const String planet = 'planet';
}
