import 'package:flutter/material.dart';

class VanillaProvider extends ChangeNotifier {
  final BuildContext context;
  VanillaProvider({
    required this.context,
  });
}
